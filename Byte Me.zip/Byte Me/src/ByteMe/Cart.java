package ByteMe;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Cart {
    private Customer customer;
    private Map<FoodItem , Double> cart;
    private double total;


    // constructor
    public Cart(Customer customer) {

        cart = new HashMap<FoodItem , Double>();
        this.customer = customer;
    }

    // adding items into the cart
    public void addToCart(FoodItem foodItem, double quantity, Admin admin) {
        if(this.cart.containsKey(foodItem)) {
            System.out.println("Already Selected !!");
            return;
        }
        if (foodItem.isAvailable() && admin.getMenu().getPriceList().contains(foodItem)) {
            this.cart.put(foodItem, quantity);
            System.out.println("FoodItem " + foodItem + " added to Cart");
            calculateTotal();
        }
        else{
            System.out.println("Not available");
        }
    }

    // Modify Quantity
    public void modifyItem(FoodItem foodItem, double quantity) {
        if(this.cart.isEmpty()){
            System.out.println("The Cart is Empty");
            return;
        }
        if (this.cart.containsKey(foodItem) && foodItem.isAvailable()){
            this.cart.put(foodItem, quantity);
            System.out.println("FoodItem " + foodItem + " modified");
            calculateTotal();
        }
        else{
            System.out.println("Not Present in the Cart");
        }
    }

    // Removing items from Cart
    public void removeItem(FoodItem foodItem) {
        if(this.cart.isEmpty()){
            System.out.println("The Cart is Empty");
            return;
        }
        if(this.cart.containsKey(foodItem) && foodItem.isAvailable()){
                    this.cart.remove(foodItem);

                     System.out.println("Removed " + foodItem.getName());
                     calculateTotal();

        }
        else{
            System.out.println("Not Present in the Cart");
        }
    }
    public void calculateTotal() {
        this.total = 0;
        for (FoodItem foodItem : this.cart.keySet()) {
              this.total += foodItem.getPrice() * this.cart.get(foodItem);
        }

    }

    // total price
    public void viewTotal(Admin admin) {
        if(this.cart.isEmpty()){
            System.out.println("The Cart is Empty");
            return;
        }
        this.total = 0;
        for (FoodItem foodItem : this.cart.keySet()) {
            if(foodItem.isAvailable() && admin.getMenu().getPriceList().contains(foodItem)){
            System.out.println("FoodItem " + foodItem + "  Quantity : " + this.cart.get(foodItem) + "  Price: " + this.cart.get(foodItem)*foodItem.getPrice());

            }
            else{
                this.cart.remove(foodItem);
            }
        }
        calculateTotal();
        if(this.total == 0){
            System.out.println("The Cart is Empty");
            return;
        }
        System.out.println("Total Bill :  " + this.total);
    }

    // checkout process
    public Order checkOut(Admin admin, Customer customer) {
        if(this.cart.isEmpty()) {
            System.out.println("The cart is empty");
            return null;
        }
        LocalDate today = LocalDate.now();
        Cart cart = customer.getCart();
        for(FoodItem foodItem : this.cart.keySet()) {
            if(!foodItem.isAvailable() || !admin.getMenu().getPriceList().contains(foodItem)) {
                System.out.println(foodItem.getName() + " is not available");
                this.cart.remove(foodItem);
            }
        }
        calculateTotal();
        if(this.cart.isEmpty()){
            System.out.println("The Cart is Empty");
            return null;
        }
        double orderTotal = this.total;
        System.out.println("Total Bill :  " + this.total);
        Order order  = new Order(customer,cart,today,orderTotal);
        this.customer.getOrders().add(order);
        return order;


    }

    public void emptyCart(){
        this.cart.clear();
    }


}
