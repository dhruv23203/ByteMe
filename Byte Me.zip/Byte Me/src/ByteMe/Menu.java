package ByteMe;

import java.sql.SQLOutput;
import java.util.*;

public class Menu {
    // initialisation
    Map<String , List<FoodItem>> categoryList;
    List <FoodItem> priceList;

    // constructor
    public Menu() {
        categoryList = new HashMap<>();
        priceList = new ArrayList<>();
    }

    // view Menu
    public void viewMenu(){;
        if(priceList.isEmpty()){
            System.out.println("No Items In Menu !!");
            return;
        }
        for (FoodItem foodItem : priceList) {
            System.out.println(foodItem);
        }
        System.out.println();
    }

   // adding items in Menu
    public void add(FoodItem foodItem , Admin admin) {
        if (admin.getPendingOrders().isEmpty()) {
            this.categoryList.computeIfAbsent(foodItem.getCategory(), k -> new ArrayList<>()).add(foodItem);
            foodItem.setPrice(foodItem.getPrice());
            foodItem.setCategory(foodItem.getCategory());
            this.priceList.add(foodItem);
            System.out.println("Food Item added");
        }
        else{
            System.out.println("Please change the Menu only when No orders are Pending ");
        }
    }

    public List<FoodItem> getPriceList() {
        return priceList;
    }

    // Searching items in Menu
    public FoodItem searchItem(String foodName) {
        if(priceList.isEmpty()){
            System.out.println("No Items In Menu !!");
            return null;
        }
        for(FoodItem foodItem : priceList) {

            if (foodItem.getName().equals(foodName)) {
                return foodItem;
            }

        }

            return null;
    }

    // filter by category
    public void filterCategory(String category) {
        if(priceList.isEmpty()){
            System.out.println("No Items In Menu !!");
            return;
        }
        if(!categoryList.containsKey(category)) {
            System.out.println("Category not found");
            return;
        }
        System.out.println("Category: " + category);
        for(FoodItem foodItem : categoryList.get(category)) {
            System.out.println(foodItem);
        }
    }

    // sorting Items Based on prices
    public void sortItemsAscending(){
        if(priceList.isEmpty()){
            System.out.println("No Items In Menu !!");
            return;
        }
        priceList.sort(Comparator.comparing(FoodItem::getPrice));
        System.out.println("Sorted By Price : Low to High");
        for(FoodItem foodItem : priceList){
            System.out.println(foodItem);
        }
    }
    public void sortItemsDescending(){
        if(priceList.isEmpty()){
            System.out.println("No Items In Menu !!");
            return;
        }
        priceList.sort(Comparator.comparing(FoodItem::getPrice).reversed());
        System.out.println("Sorted By Price : High to Low");
        for(FoodItem foodItem : priceList){
            System.out.println(foodItem);
        }
    }

    // Update Items
    public void updateItems(FoodItem foodItem , int price , String category) {
        if(priceList.isEmpty()){
            System.out.println("No Items In Menu !!");
            return;
        }
        if(priceList.contains(foodItem)) {
            this.priceList.remove(foodItem);
            this.categoryList.get(foodItem.getCategory()).remove(foodItem);
            foodItem.setPrice(price);
            foodItem.setCategory(category);
            this.categoryList.computeIfAbsent(category, k -> new ArrayList<>()).add(foodItem);
            this.priceList.add(foodItem);
            System.out.println("Item Updated Successfully");

        }
        else{
            System.out.println("Not present in the Menu");
        }


    }

    // removing Items
    public void remove(FoodItem foodItem, Admin admin) {

        if(admin.getPendingOrders().isEmpty()) {

        if(priceList.isEmpty()){
            System.out.println("No Items In Menu !!");
            return;
        }
        if(priceList.contains(foodItem)) {
            this.priceList.remove(foodItem);
            this.categoryList.get(foodItem.getCategory()).remove(foodItem);
            foodItem = null;
            System.out.println("Item Removed Successfully");

        }
        else{
            System.out.println("Not present in the Menu");
        }
        }
        else{
            System.out.println("Please change the Menu only when No orders are Pending ");
        }

    }

    // modifying price
    public void modifyPrice(FoodItem foodItem , int price) {
        if(priceList.isEmpty()){
            System.out.println("No Items In Menu !!");
            return;
        }
        if(priceList.contains(foodItem)) {
              this.priceList.remove(foodItem);
              foodItem.setPrice(price);
              this.priceList.add(foodItem);
              System.out.println("Price Updated Successfully");
        }
        else{
            System.out.println("Not present in the Menu");
        }

    }

    // update Availablity
    public void updateAvailablility(FoodItem foodItem , boolean available ,Admin admin) {
        if(admin.getPendingOrders().isEmpty()) {

        if(priceList.isEmpty()){
            System.out.println("No Items In Menu !!");
            return;
        }
        foodItem.setAvailable(available);
        System.out.println("Availability Updated Successfully");
        }
        else{
            System.out.println("Please change the Menu only when No orders are Pending ");
        }

    }

    public boolean isEmpty(){
        if(priceList.isEmpty()){
            return true;

        }
        return false;
    }





}
