package ByteMe;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Customer{
    private String name;
    private String address;
    private String phone;
    private Order currentOrder;
    private List<Order> orders;
    private Cart cart;

    public Customer(String name, String address,String phone) {
        this.name = name;
        this.address = address;
        this.cart = new Cart(this);
        this.orders = new ArrayList<>();

    }

    public String getAddress() {
        return address;
    }

    public String getName() {
        return name;
    }

    public void setCurrentOrder(Order currentOrder) {
        this.currentOrder = currentOrder;
    }

    public ByteMe.Cart getCart() {
        return this.cart;
    }

    public List<Order> getOrders() {
        return this.orders;
    }

    // view all items in Menu
    public void viewMenu(Admin admin) {
        admin.getMenu().viewMenu();
    }

    public FoodItem searchMenu(Admin admin , String search) {
        FoodItem item = admin.getMenu().searchItem(search);
        return item;
    }

    public void filterMenu(Admin admin , String filter) {
        admin.getMenu().filterCategory(filter);
    }

    public void sortMenuAscending(Admin admin) {
        admin.getMenu().sortItemsAscending();
    }
    public void sortMenuDescending(Admin admin) {
        admin.getMenu().sortItemsDescending();
    }

    public void placeOrder(Admin admin , Scanner scanner) {

        if(this.currentOrder != null) {
            System.out.println("Please wait until your current order is not delivered");
            return;
        }
        this.currentOrder = this.cart.checkOut(admin ,this);
        Cart cart = this.cart;
        if(this.currentOrder == null) {
            return;
        }


            System.out.println("Enter the Delivery Address : ");
            String address = scanner.nextLine();
            this.currentOrder.setOrderAddress(address);



        this.currentOrder.setCart(cart);
        admin.getPendingOrders().add(this.currentOrder);
        System.out.println("Order Placed successfully and will be Delivered to " + address + " shortly ");

    }

    public void viewStatus(){
        System.out.println("Order Status : " + this.currentOrder.getOrderStatus());
    }

    public Order getCurrentOrder() {
        return this.currentOrder;
    }

    public void cancelOrder() {
        if(this.currentOrder == null) {
            System.out.println("You have not placed any Order");
            return;
        }
        if(currentOrder.getOrderStatus().equalsIgnoreCase("Cancelled")) {
            System.out.println("Already cancelled !!");
            return;
        }


        this.currentOrder.setOrderStatus("Cancelled");
//        this.cart.emptyCart();
        System.out.println("Order cancelled");

    }

    public void getOrderHistory(){
        if(orders.isEmpty()) {
            System.out.println("You have not placed any Order");
            return;
        }
        for(Order order : orders){
            System.out.println(order);
        }
    }
    public void specialRequest(String request ){

        this.currentOrder.setSpecialRequest(request);
        System.out.println("Request has been sent to the Admin ");
    }



    public void displayBrowseMenu(){
        System.out.println("BROWSE MENU");
        System.out.println("1. View all items");
        System.out.println("2. Search By Name");
        System.out.println("3. Filter by category");
        System.out.println("4. Sort by price : Low to High :");
        System.out.println("5. Sort by price : High to Low :");
    }

    public void displayCartOperations(){
        System.out.println("CART OPERATIONS");
        System.out.println("1. Add items");
        System.out.println("2. Modify quantities");
        System.out.println("3. Remove items");
        System.out.println("4. View Total ");
        System.out.println("5. Checkout ");

    }
    public void displayOrderTracking(){
        System.out.println("ORDER TRACKING");
        System.out.println("1. View order status");
        System.out.println("2. Cancel order");
        System.out.println("3. Order History");
        System.out.println("4. Special Request");



    }
    public void displayFeature(){
        System.out.println("CUSTOMER INTERFACE ");
        System.out.println("1. Browse Menu");
        System.out.println("2. Cart Operations");
        System.out.println("3. Order Tracking");
    }

}
