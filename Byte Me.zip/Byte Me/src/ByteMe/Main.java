package ByteMe;

import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
    private static Admin admin = new Admin();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        initializeData();

        System.out.println("Welcome to Byte Me!");
        while (true) {
            System.out.println("   MAIN MENU   ");
            System.out.println();
            System.out.println("1. Login as Admin");
            System.out.println("2. Login as New Customer");
            System.out.println("3. Existing Customer");
            System.out.println("4. Exit");


            System.out.println("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1: handleAdminMenu(admin,scanner);
                        break;
                case 2:
                    System.out.println("Enter your Name : ");
                    String name = scanner.nextLine();
                    System.out.println("Enter your Address : ");
                    String address = scanner.nextLine();
                    System.out.println("Enter your Phone Number : ");
                    String phoneNumber = scanner.nextLine();

                    Customer dummyCustomer = admin.getCustomerList().get(phoneNumber);
                    if(dummyCustomer == null) {
                        Customer newCustomer = new Customer(name, address, phoneNumber);
                        admin.getCustomerList().put(phoneNumber, newCustomer);
                        handleCustomerMenu(newCustomer,scanner);
                    }
                    else{
                        System.out.println("Customer already exists");
                    }
                    break;

                case 3:
                    System.out.println("Enter your Phone Number : ");
                    String phoneNo = scanner.nextLine();
                    if(admin.getCustomerList().containsKey(phoneNo)) {
                        Customer customer = admin.getCustomerList().get(phoneNo);
                        handleCustomerMenu(customer,scanner);
                    }
                    else{
                        System.out.println("Customer does not exist");
                    }
                    break;
                case 4:
                    System.out.println("Exiting Portal ...... ");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice");
                    break;

            }




        }
    }
     public static void initializeData(){
        Customer customer1 = new Customer("A","A","1");
        Customer customer2 = new Customer("B","B","2");
        Customer customer3 = new Customer("C","C","3");
        admin.getCustomerList().put("1",customer1);
        admin.getCustomerList().put("2",customer2);
        admin.getCustomerList().put("3",customer3);

        FoodItem foodItem1 = new FoodItem("PEPSI",170,"SOUTH");
        FoodItem foodItem2 = new FoodItem("MAAZA",150,"SOUTH");
        FoodItem foodItem3 = new FoodItem("DOSA",15,"PUNJABI");

        admin.addMenu(foodItem1);
        admin.addMenu(foodItem2);
        admin.addMenu(foodItem3);


     }

     public static void handleCustomerMenu(Customer customer, Scanner scanner) {
        while(true){
            customer.displayFeature();
            System.out.println("Enter your choice ( or 0 to Go Back) : ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            if(choice == 0){
                break;
            }
            switch (choice) {



                case 1: customer.displayBrowseMenu();
                        System.out.println("Enter your choice ( or 0 to Go Back) : ");
                        int choice2 = scanner.nextInt();
                        scanner.nextLine();

                        switch (choice2) {
                            case 0: break;

                            case 1: customer.viewMenu(admin);
                                   break;
                            case 2:
                                System.out.println("Enter the Name of FoodItem : ");
                                String name = scanner.nextLine();
                                FoodItem food = customer.searchMenu(admin,name);
                                if(food != null) {
                                System.out.println(food);

                                }
                                else{
                                    System.out.println("Food Item not found");
                                }
                                break;

                            case 3:
                                System.out.println("Enter the Category of FoodItem : ");
                                String category = scanner.nextLine();
                                customer.filterMenu(admin,category);
                                break;

                            case 4:
                                 customer.sortMenuAscending(admin);
                                 break;
                            case 5:
                                customer.sortMenuDescending(admin);
                                break;
                            default:
                                System.out.println("Invalid choice");

                        }
                        break;
                case 2 : customer.displayCartOperations();
                         System.out.println("Enter your choice ( or 0 to Go Back) : ");
                         int choice3 = scanner.nextInt();
                         scanner.nextLine();
                         switch (choice3) {
                             case 0: break;
                             case 1:
                                 if(customer.getCurrentOrder() != null){
                                     System.out.println("Please wait while your current order is being processed ");
                                     break;
                                 }
                                 System.out.println("Enter the Name of FoodItem : ");
                                 String name = scanner.nextLine();
                                 FoodItem food = customer.searchMenu(admin,name);
                                 if(food != null ) {
                                       if(food.isAvailable()){

                                       System.out.println("Enter Quantity required : ");
                                       int quantity = scanner.nextInt();
                                       scanner.nextLine();
                                       customer.getCart().addToCart(food,quantity,admin);
                                       }
                                       else{
                                           System.out.println("Food item not available");
                                           }

                                 }
                                 else{
                                     System.out.println("Food Item not found");
                                 }
                                 break;

                             case 2:
                                 if(customer.getCurrentOrder() != null){
                                     System.out.println("Please wait while your current order is being processed ");
                                     break;
                                 }
                                 System.out.println("Enter the Name of FoodItem : ");
                                 String foodname = scanner.nextLine();
                                 FoodItem fooditem = customer.searchMenu(admin,foodname);
                                 if(fooditem != null) {
                                     System.out.println("Enter Quantity required : ");
                                     int quantity = scanner.nextInt();
                                     scanner.nextLine();
                                     customer.getCart().modifyItem(fooditem,quantity);
                                 }
                                 else{
                                     System.out.println("Food Item not found");
                                 }
                                 break;

                             case 3:
                                 if(customer.getCurrentOrder() != null){
                                     System.out.println("Please wait while your current order is being processed ");
                                     break;
                                 }
                                 System.out.println("Enter the Name of FoodItem : ");
                                 String foodname2= scanner.nextLine();
                                 FoodItem fooditem2 = customer.searchMenu(admin,foodname2);
                                 if(fooditem2 != null || fooditem2.isAvailable()) {
                                     customer.getCart().removeItem(fooditem2);
                                 }
                                 else{
                                     System.out.println("Food Item not found");
                                 }
                                 break;

                             case 4:
                                 customer.getCart().viewTotal(admin);
                                 break;

                             case 5:
                                 customer.placeOrder(admin , scanner);
                                 break;

                             default:
                                 System.out.println("Invalid choice");
                         }
                         break;
                case 3:
                    customer.displayOrderTracking();
                    System.out.println("Enter your choice ( or 0 to Go Back) : ");
                    int choice4 = scanner.nextInt();
                    scanner.nextLine();
                    switch (choice4) {
                        case 0: break;

                        case 1: if(customer.getCurrentOrder() == null){
                                      System.out.println("You have not placed Any Order");
                                }
                                else{
                                  String status = customer.getCurrentOrder().getOrderStatus();
                                  System.out.println("Status : " + status);

                                }
                                break;
                        case 2:
                            customer.cancelOrder();
                            break;

                        case 3:
                            customer.getOrderHistory();
                            break;

                        case 4:
                            if(customer.getCurrentOrder() != null){

                            System.out.println("Enter the Special Request : ");
                            String specialRequest = scanner.nextLine();
                            customer.specialRequest(specialRequest);
                            }
                            else{
                                System.out.println("You have not placed Any Order");
                            }
                            break;
//                        case 5 :
//                            customer.reorder(admin , scanner);
//                            break;
                    }
                    break;
                default:
                    System.out.println("Invalid choice");
            }

        }


     }
     public static void handleAdminMenu(Admin admin , Scanner scanner) {
        while(true){
            admin.displayFeature();
            System.out.println("Enter your choice ( or 0 to Go Back) : ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            if(choice == 0){
                break;
            }
            switch (choice) {

                case 1 :
                      admin.displayMenuManagement();
                      System.out.println("Enter your choice ( or 0 to Go Back) : ");
                      int choice2 = scanner.nextInt();
                      scanner.nextLine();
                      switch (choice2) {

                          case 0:
                              break;
                          case 1:
                              System.out.println("Enter the Name of FoodItem : ");
                              String name = scanner.nextLine();

                              if (admin.getMenu().searchItem(name) == null) {
                                  System.out.println("Enter Price : ");
                                  int price = scanner.nextInt();
                                  scanner.nextLine();
                                  System.out.println("Enter Category of FoodItem : ");
                                  String category = scanner.nextLine();

                                  FoodItem foodItem = new FoodItem(name, price, category);
                                  admin.getMenu().add(foodItem,admin);

                              }
                              else{
                                  System.out.println("Food Item already exists");
                              }

                              break;
                          case 2:
                              System.out.println("Enter the Name of FoodItem : ");
                              String foodname2 = scanner.nextLine();
                              FoodItem food = admin.getMenu().searchItem(foodname2);
                              if (food != null) {
                                  System.out.println("Enter new Price : ");
                                  int price2 = scanner.nextInt();
                                  scanner.nextLine();
                                  System.out.println("Enter Category of FoodItem : ");
                                  String category2 = scanner.nextLine();
                                  admin.update(food, price2, category2);

                              }
                              else{
                                  System.out.println("Food Item not found");
                              }
                              break;


                          case 3:
                              System.out.println("Enter the Name of FoodItem : ");
                              String foodname = scanner.nextLine();
                              FoodItem foodItem1 = admin.getMenu().searchItem(foodname);
                              if (foodItem1 != null) {
                                  admin.getMenu().remove(foodItem1 ,admin);
                              }
                              else{
                                  System.out.println("Food Item not found");
                              }
                              break;

                          case 4:
                              System.out.println("Enter the Name of FoodItem : ");
                              String foodname3 = scanner.nextLine();
                              FoodItem fooditem2 = admin.getMenu().searchItem(foodname3);
                              if (fooditem2 != null) {
                                  System.out.println("Enter new Price : ");
                                  int price3 = scanner.nextInt();
                                  scanner.nextLine();
                                  admin.modifyPrice(fooditem2, price3);
                              }
                              else{
                                  System.out.println("Food Item not found");
                              }
                              break;

                          case 5:
                              System.out.println("Enter the Name of FoodItem : ");
                              String foodname4 = scanner.nextLine();
                              FoodItem fooditem3 = admin.getMenu().searchItem(foodname4);
                              if (fooditem3 != null) {
                                  System.out.println("Enter Availablity : (true or false)");
                                  boolean avail = scanner.nextBoolean();
                                  admin.getMenu().updateAvailablility(fooditem3, avail,admin);

                              }
                              else{
                                  System.out.println("Food Item not found");
                              }
                              break;
                          default:
                              System.out.println("Invalid choice");
                     }
                     break;
                case 2 :
                    admin.displayOrderManagement();
                    System.out.println("Enter your choice ( or 0 to Go Back) : ");
                    int choice4 = scanner.nextInt();
                    scanner.nextLine();
                    switch (choice4) {
                        case 0: break;
                        case 1 :
                            admin.viewPendingOrders();
                            break;
                        case 2:
                            System.out.println("Enter the Phone Number of the Customer : ");
                            String phone = scanner.nextLine();
                            if(admin.getCustomerList().containsKey(phone)){
                                Customer customer = admin.getCustomerList().get(phone);
                                if(customer.getCurrentOrder() != null){

                                System.out.println("Enter Status : ( Delivered )");
                                String status = scanner.nextLine();
                                if(status.equalsIgnoreCase("Delivered")){
                                    admin.updateStatus(customer.getCurrentOrder(),status);

                                }
                                else{
                                    System.out.println("Invalid Status");
                                }
                                }
                                else{
                                    System.out.println("No orders found");
                                }



                            }
                            else{
                                System.out.println("No orders found");
                            }
                            break;

                        case 3:
                            System.out.println("Enter the Phone Number of the Customer : ");
                            String phone2 = scanner.nextLine();
                            if(admin.getCustomerList().containsKey(phone2)){
                                Customer customer = admin.getCustomerList().get(phone2);
                                if(customer.getCurrentOrder()!=null){
                                  admin.processRefunds(customer.getCurrentOrder());

                                }
                                else{
                                    System.out.println("No orders found");
                                }

                            }
                            else{
                                System.out.println("Customer does not exist ");
                            }
                            break;
                        case 4:
                            System.out.println("Enter the Phone Number of the Customer : ");
                            String phone3 = scanner.nextLine();
                            if(admin.getCustomerList().containsKey(phone3)){
                                Customer customer = admin.getCustomerList().get(phone3);
                                admin.handleRequest(customer.getCurrentOrder());
                            }
                            else{
                                System.out.println("Customer does not exist ");
                            }

                                break;
                        case 5:
                            admin.viewSpecialRequest();
                            break;
                        default:
                                System.out.println("Invalid choice");
                    }
                    break;

                case 3:
                    admin.displayReportGeneration();
                    admin.dailyReport();
                    break;
                default:
                    System.out.println("Invalid choice");

            }
        }

     }

}