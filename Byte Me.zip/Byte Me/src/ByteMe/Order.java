package ByteMe;


import java.time.LocalDate;


public class Order {

    private Customer customer;
    private Cart cart;
    private String orderStatus;

    private double orderTotal;

    private LocalDate orderDate;
    private String specialRequest;


    private String orderAddress;

    public Order(Customer customer, Cart cart, LocalDate orderDate , double orderTotal) {
        this.customer = customer;
        this.cart = cart;
        this.orderDate = orderDate;
        this.orderStatus = "Pending";
        this.specialRequest = null;
        this.orderAddress = null;
        this.orderTotal = orderTotal;

    }

    public String getOrderStatus() {
        return this.orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Customer getCustomer() {
        return this.customer;
    }

    @Override
    public String toString() {
        return ("Customer Name : " + this.customer.getName() + " Status : " + this.orderStatus + " Date : " + this.orderDate + " Total : " + this.orderTotal);
    }

    public LocalDate getOrderDate() {
        return this.orderDate;
    }

    public String getSpecialRequest() {
        return this.specialRequest;
    }

    public void setSpecialRequest(String specialRequest) {
        this.specialRequest = specialRequest;
    }

    public void setOrderAddress(String orderAddress) {
        this.orderAddress = orderAddress;
    }

    public Cart getCart() {
        return this.cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public double getOrderTotal() {
        return orderTotal;
    }

    public void setOrderTotal(double orderTotal) {
        this.orderTotal = orderTotal;
    }
}