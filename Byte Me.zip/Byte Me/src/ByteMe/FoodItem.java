package ByteMe;

public class FoodItem {
    private String name;
    private int price;
    private String category;
    private boolean isAvailable;

    public FoodItem(String name, int price, String category) {
        this.name = name;
        this.price = price;
        this.category = category;
        this.isAvailable = true;
    }

    public String getCategory() {
        return this.category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public boolean isAvailable() {
        return this.isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }
    public String available() {
        if (isAvailable) {
            return "Available" ;
        }
        else {
            return "Not Available" ;
        }
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return this.price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "name = " + name + ", price = " + price + ", category = " + category  +"  " + available();
    }
}
