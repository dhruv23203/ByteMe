package ByteMe;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Admin {
    private Map<LocalDate , List<Order>> completedOrders = new HashMap<>();
    private Map<String ,Customer> customerList = new HashMap<>();
    private List<Order> pendingOrders = new ArrayList<>();


    private Menu menu;

    public Admin() {
        this.menu =  new Menu();
    }

    public Menu getMenu() {
        return this.menu;
    }

    public List<Order> getPendingOrders() {
        return this.pendingOrders;
    }

    public Map<LocalDate, List<Order>> getCompletedOrders() {
        return this.completedOrders;
    }

    // add items in Menu
    public void addMenu(FoodItem foodItem) {
        this.menu.add(foodItem,this);
    }

    //update existing items
    public void update(FoodItem foodItem , int price , String category) {
        this.menu.updateItems(foodItem, price, category);
    }

    // remove items
    public void removeInMenu(FoodItem foodItem,Admin admin) {
        this.menu.remove(foodItem ,admin);
    }
    public void modifyPrice(FoodItem foodItem, int price) {
        this.menu.modifyPrice(foodItem, price);
    }

    // modify price
    public void modifyMenu(FoodItem foodItem , int price ) {
        this.menu.modifyPrice(foodItem, price);
    }

    //availability
    public void setAvailability(FoodItem foodItem ,Boolean availability) {
        this.menu.updateAvailablility(foodItem , availability,this);

    }
    // viewing pending Orders
    public void viewPendingOrders() {
        if(pendingOrders.isEmpty()){
            System.out.println("No pending orders");
            return;
        }
        for (Order order : pendingOrders) {
            System.out.println(order);
        }
    }

    // update order status
    public void updateStatus(Order order , String status) {
        if(status.equalsIgnoreCase("Delivered")){
            order.setOrderStatus("Delivered");
            this.pendingOrders.remove(order);
            completedOrders.computeIfAbsent(LocalDate.now(), k -> new ArrayList<>()).add(order);
            order.getCustomer().setCurrentOrder(null);
//            order.getCustomer().getOrders().add(order);
            order.getCustomer().getCart().emptyCart();
            System.out.println("Your order is Delivered ");
            return;
        }

        System.out.println("No order of this type");

    }

    // processing refunds
    public void processRefunds(Order order) {
        if(order.getOrderStatus().equalsIgnoreCase("Cancelled")) {
            System.out.println("The amount has been refunded to the customer");
            order.setOrderStatus("Refunded");
            this.pendingOrders.remove(order);
            this.completedOrders.computeIfAbsent(LocalDate.now(), k -> new ArrayList<>()).add(order);
            order.getCustomer().setCurrentOrder(null);
            order.getCustomer().getCart().emptyCart();
//            order.getCustomer().getOrders().add(order);


        }
        else{
            System.out.println("No refund request is raised ");
        }
    }

    public void dailyReport(){
        double totalSales = 0;
        int totalOrders = 0;
        if(completedOrders.isEmpty()){
            System.out.println("No orders !!! ");
        }
        for(Map.Entry<LocalDate, List<Order>> entry : completedOrders.entrySet()) {
            System.out.println("Orders for Date : " + entry.getKey());
            for(Order order : entry.getValue()) {
                System.out.println(order);
                if(order.getOrderStatus().equalsIgnoreCase("Delivered")){
                    totalSales += order.getOrderTotal();
                    totalOrders++;
                }
            }
        }
        System.out.println();
        System.out.println("Total Orders : " + totalOrders);
        System.out.println("Total sales : " + totalSales);
    }
    public void handleRequest(Order order) {
        if(order == null){
            System.out.println("No order has been placed !!");
            return;
        }
        if(order.getSpecialRequest() == null){
            System.out.println("No special request has been placed !!");
            return;
        }
        System.out.println(order.getSpecialRequest() + " by Customer " + order.getCustomer().getName());
        System.out.println("The Request has been received");
    }

    public void viewSpecialRequest() {
        Boolean isPrint = false;
        if(pendingOrders.isEmpty()){
            System.out.println("No pending orders");
        }
        for(Order order : pendingOrders){
            if(order.getSpecialRequest() != null){
                System.out.println("Request : " + order.getSpecialRequest() + " by Customer " + order.getCustomer().getName());
                isPrint = true;
            }
        }
        if(!isPrint){
            System.out.println("No special request has been placed !!");
        }
    }

    public void displayMenuManagement(){
        System.out.println("MENU MANAGEMENT");
        System.out.println("1. Add new items");
        System.out.println("2. Update existing items");
        System.out.println("3. Remove items");
        System.out.println("4. Modify Prices");
        System.out.println("5. Update availability");
    }

    public void displayOrderManagement(){
        System.out.println("ORDER MANAGEMENT ");
        System.out.println("1. View pending orders");
        System.out.println("2. Update order status");
        System.out.println("3. Process refunds");
        System.out.println("4. Handle special requests");
        System.out.println("5. View special requests");
    }

    public void displayReportGeneration(){
        System.out.println("1. Daily Sales Report");
    }

    public void displayFeature(){
        System.out.println("ADMIN INTERFACE ");
        System.out.println("1. Menu Management");
        System.out.println("2. Order Management");
        System.out.println("3. Report Generation");
    }

    public Map<String, Customer> getCustomerList() {
        return customerList;
    }
}
